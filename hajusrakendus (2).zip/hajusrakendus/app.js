const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./db');
const country = require('./routes/country');
const city = require('./routes/city');
const product = require('./routes/product');
const customers = require('./routes/customers');
const sales = require('./routes/sales');
const productLine = require('./routes/productLine');
const company = require('./routes/company');
const payment = require('./routes/payment');
const productCategories = require('./routes/productCategories');

const app = express();

app.use(bodyParser.json());

app.use('/country', country);
app.use('/city', city);
app.use('/product', product);
app.use('/customers', customers);
app.use('/sales', sales);
app.use('/productLine', productLine);
app.use('/company', company);
app.use('/payment', payment);
app.use('/productCategories', productCategories);

app.use((req, res, next) => {
    res.status(404).send('Not found');
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Server error');
});

sequelize.sync()
    .then(() => {
        console.log('Connected to the database');
        app.listen(3000, () => {
            console.log('Server is running on port 3000');
        });
    })
    .catch(err => console.error('Error connecting to the database:', err));
