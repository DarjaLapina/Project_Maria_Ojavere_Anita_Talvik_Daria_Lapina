const {Sequelize} = require('sequelize')

const sequelize = new Sequelize('1a', '1a', '1a', {
    dialect: "mysql",
    host: "localhost"
})

module.exports = sequelize;
