const express = require('express');
const router = express.Router();
const Company = require('../models/company');

router.post('/companies', async (req, res) => {
    try {
        const { Com_id, Com_name } = req.body;
        const newCompany = await Company.create({
            Com_id,
            Com_name
        });
        res.status(201).json(newCompany);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при добавлении компании' });
    }
});

module.exports = router;
