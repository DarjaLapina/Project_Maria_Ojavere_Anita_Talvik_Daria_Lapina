const express = require('express');
const router = express.Router();
const Country = require('../models/country');

router.post('/countries', async (req, res) => {
    try {
        const { C_id, C_name } = req.body;
        const newCountry = await Country.create({
            C_id,
            C_name
        });
        res.status(201).json(newCountry);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при добавлении страны' });
    }
});

module.exports = router;
