const express = require('express');
const router = express.Router();
const ProductCategory = require('../models/productCategories');

router.post('/productCategories', async (req, res) => {
    try {
        const { P_C_id, P_C_name } = req.body;
        const newProductCategory = await ProductCategory.create({
            P_C_id,
            P_C_name
        });
        res.status(201).json(newProductCategory);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при добавлении категории продуктов' });
    }
});

router.get('/productCategories', async (req, res) => {
    try {
        const productCategories = await ProductCategory.findAll();
        res.status(200).json(productCategories);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при выборе категорий продуктов' });
    }
});

module.exports = router;
