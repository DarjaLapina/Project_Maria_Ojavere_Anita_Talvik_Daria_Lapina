const express = require('express');
const router = express.Router();
const Payment = require('../models/payment');

router.post('/payments', async (req, res) => {
    try {
        const { Pay_id, Pay_data, Cu_id, Sal_id } = req.body;
        const newPayment = await Payment.create({
            Pay_id,
            Pay_data,
            Cu_id,
            Sal_id
        });
        res.status(201).json(newPayment);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при обработке оплаты товаров' });
    }
});

module.exports = router;
