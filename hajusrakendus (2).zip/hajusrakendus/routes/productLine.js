const express = require('express');
const router = express.Router();
const ProductLine = require('../models/productLine');

router.post('/productLines', async (req, res) => {
    try {
        const { P_L_id, P_L_name, P_C_id } = req.body;
        const newProductLine = await ProductLine.create({
            P_L_id,
            P_L_name,
            P_C_id
        });
        res.status(201).json(newProductLine);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при добавлении марки продукта' });
    }
});

router.get('/product-lines', async (req, res) => {
    try {
        const productLines = await ProductLine.findAll();
        res.status(200).json(productLines);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при выборе марок продуктов' });
    }
});

module.exports = router;
