const express = require('express');
const router = express.Router();
const Product = require('../models/product');

router.post('/products', async (req, res) => {
    try {
        const { Pr_id, Pr_name, Pr_amount, Pr_description, Pr_price, P_L_id, Com_id } = req.body;
        const newProduct = await Product.create({
            Pr_id,
            Pr_name,
            Pr_amount,
            Pr_description,
            Pr_price,
            P_L_id,
            Com_id
        });
        res.status(201).json(newProduct);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при добавлении товара' });
    }
});

router.post('/products/sell', async (req, res) => {
    try {
        const { Pr_id } = req.body;
        const product = await Product.findByPk(Pr_id);
        if (!product) {
            return res.status(404).json({ message: 'Товар не найден' });
        }
        product.status = 'продан';
        await product.save();
        res.status(200).json({ message: 'Товар успешно продан' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при продаже товара' });
    }
});
module.exports = router;