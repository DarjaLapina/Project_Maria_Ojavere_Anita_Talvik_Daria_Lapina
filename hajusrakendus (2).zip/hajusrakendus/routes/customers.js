const express = require('express');
const router = express.Router();
const Customer = require('../models/сustomers');

router.post('/customers', async (req, res) => {
    try {
        const { Cu_id, Cu_name, Cu_last_name, Cu_phone, Cu_mail, Cu_kart_number, C_id } = req.body;
        const newCustomer = await Customer.create({
            Cu_id,
            Cu_name,
            Cu_last_name,
            Cu_phone,
            Cu_mail,
            Cu_kart_number,
            C_id
        });
        res.status(201).json(newCustomer);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка при добавлении покупателя' });
    }
});

module.exports = router;
