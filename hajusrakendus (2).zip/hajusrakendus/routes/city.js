const express = require('express');
const router = express.Router();
const City = require('../models/сity');

router.post('/cities', async (req, res) => {
    try {
        const { Ci_id, Ci_name, C_id } = req.body;
        const newCity = await City.create({
            Ci_id,
            Ci_name,
            C_id
        });
        res.status(201).json(newCity);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Ошибка при добавлении города' });
    }
});

module.exports = router;
