const { Sequelize, DataTypes } = require('sequelize');
const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const City = db.define('City', {
    Ci_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    Ci_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    C_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Country',
            key: 'C_id'
        }
    }
}, {
    timestamps: false,
    tableName: 'City'
});

module.exports = City;
