const { Sequelize, DataTypes } = require('sequelize');
const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const Sales = db.define('Sales', {
    Sal_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    Pr_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Product',
            key: 'Pr_id'
        }
    }
}, {
    timestamps: false,
    tableName: 'Sales'
});

module.exports = Sales;
