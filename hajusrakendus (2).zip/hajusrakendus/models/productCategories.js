const { Sequelize, DataTypes } = require('sequelize');
const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const ProductCategories = db.define('ProductCategories', {
    P_C_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    P_C_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    }
}, {
    timestamps: false,
    tableName: 'ProductCategories'
});

module.exports = ProductCategories;
