const { Sequelize, DataTypes } = require('sequelize');
const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const Product = db.define('Product', {
    Pr_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    Pr_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    Pr_amount: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    Pr_description: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    Pr_price: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    P_L_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Product_line',
            key: 'P_L_id'
        }
    },
    Com_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Company',
            key: 'Com_id'
        }
    }
}, {
    timestamps: false,
    tableName: 'Product'
});

module.exports = Product;
