const { Sequelize, DataTypes } = require('sequelize');
const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const ProductLine = db.define('ProductLine', {
    P_L_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    P_L_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    P_C_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'ProductCategories',
            key: 'P_C_id'
        }
    }
}, {
    timestamps: false,
    tableName: 'ProductLine'
});

module.exports = ProductLine;
