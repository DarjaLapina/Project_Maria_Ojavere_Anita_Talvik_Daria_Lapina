const { Sequelize, DataTypes } = require('sequelize');

const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const Country = db.define('Country', {
    C_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    C_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    }
}, {
    timestamps: false,
    tableName: 'Country'
});

module.exports = Country;
