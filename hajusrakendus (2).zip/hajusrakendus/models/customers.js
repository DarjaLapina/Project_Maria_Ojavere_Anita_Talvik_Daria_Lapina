const { Sequelize, DataTypes } = require('sequelize');
const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const Customers = db.define('Customers', {
    Cu_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    Cu_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    Cu_last_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    Cu_phone: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    Cu_mail: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    Cu_kart_number: {
        type: DataTypes.STRING(150),
        allowNull: false
    },
    C_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Country',
            key: 'C_id'
        }
    }
}, {
    timestamps: false,
    tableName: 'Customers'
});

module.exports = Customers;
