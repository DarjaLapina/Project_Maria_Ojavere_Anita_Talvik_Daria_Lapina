const { Sequelize, DataTypes } = require('sequelize');
const db = new Sequelize({
    dialect: "mysql",
    host: "localhost",
    username: "1a",
    password: "1a", 
    database: "1a"
});

const Company = db.define('Company', {
    Com_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        allowNull: false
    },
    Com_name: {
        type: DataTypes.STRING(150),
        allowNull: false
    }
}, {
    timestamps: false,
    tableName: 'Company'
});

module.exports = Company;
